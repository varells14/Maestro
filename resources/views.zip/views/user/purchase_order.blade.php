@extends('layouts.app')

@section('content')
<div class="d-flex flex-column justify-content-center align-items-center" style="height: 80vh;">
    <h1 class="display-4 text-center">COMING SOON</h1>
    <p class="lead text-center mt-3">This page is under construction and will soon be available for Purchase Order. Please stay tuned!</p>
</div>
@endsection
