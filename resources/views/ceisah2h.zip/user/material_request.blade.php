@extends('layouts.app')

@section('content')
<div class="container-fluid my-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
            <h3 class="m-0 font-weight-bold">Materials Request</h3>
            <div class="d-flex gap-2">
                <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#filterModal">
                    <i class="fas fa-filter"></i> Filter Material Request
                </button>
                <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addRequestModal">
                    <i class="fas fa-plus"></i> Request Material
                </button>
            </div>
        </div>

        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <div class="mb-4">
                <input type="text" id="searchInput" class="form-control" placeholder="Search requests...">
            </div>

            <div class="row" id="requestsContainer">
                @forelse($requests as $request)
                    @php
                        $statusColor = match($request->status) {
                            'approved' => 'success',
                            'pending' => 'warning',
                            'rejected' => 'danger',
                            default => 'success'
                        };
                        
                        $priorityColor = match($request->priority) {
                            'High' => 'danger',
                            'Medium' => 'warning',
                            'Low' => 'info',
                            'Urgent' => 'dark',
                            default => 'success'
                        };

                        $requestNumber = $request->request_number ?? 'MR-'.str_pad($request->id, 4, '0', STR_PAD_LEFT);
                    @endphp
                    <div class="col-md-6 col-lg-4 mb-4 request-card-wrapper">
                        <div class="card h-100 border-top border-3 border-primary shadow-sm hover-shadow request-card" data-id="{{ $request->id }}">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="card-title mb-0 text-truncate" title="{{ $request->request_name }}">
                                        {{ $request->request_name }}
                                    </h5>
                                    <span class="badge bg-{{ $statusColor }}">{{ ucfirst($request->status) }}</span>
                                </div>
                                
                                <div class="card-text">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted"><i class="fas fa-hashtag me-1"></i> {{ $requestNumber }}</span>
                                        <span class="badge bg-{{ $priorityColor }}">{{ $request->priority ?? 'Normal' }}</span>
                                    </div>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fas fa-tag me-1 text-muted"></i>
                                        <span>{{ $request->project }}</span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-calendar-alt me-1 text-muted"></i>
                                        <span>{{ $request->request_date ? \Carbon\Carbon::parse($request->request_date)->format('d-m-Y') : 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent d-flex justify-content-end">
                                <button class="btn btn-primary btn-sm view-details" data-id="{{ $request->id }}">
                                    <i class="fas fa-eye me-1"></i> Details
                                </button>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No material requests found</h5>
                        <p class="text-muted">Click "Request Material" to create a new request</p>
                    </div>
                @endforelse
            </div>
        </div>
    </div>
</div>

<!-- Add Request Modal -->
<div class="modal fade" id="addRequestModal" tabindex="-1" aria-labelledby="addRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addRequestModalLabel">Request New Material</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="requestForm" action="{{ route('user.material_request.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="row mb-3">
                    <div class="col-md-6">
                            <label for="project" class="form-label">Project <span class="text-danger">*</span></label>
                            <select class="form-select" id="project" name="project" required>
                                <option value="" disabled selected>Select a Project</option>
                                @foreach($project as $project)
                                    <option value="{{ $project->project }}">{{ $project->project }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="request_name" class="form-label">Request Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control text-uppercase" id="request_name" name="request_name" oninput="this.value = this.value.toUpperCase();" required>
                        </div>
                        <div class="col-md-6">
                            <label for="request_number" class="form-label">Request Number</label>
                            <input type="text" class="form-control" id="request_number" name="request_number" placeholder="Automatically Generated" readonly>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="priority" class="form-label">Priority <span class="text-danger">*</span></label>
                            <select class="form-select" id="priority" name="priority" required>
                                <option value="LOW">LOW</option>
                                <option value="MEDIUM" selected>MEDIUM</option>
                                <option value="HIGH">HIGH</option>
                                <option value="URGENT">URGENT</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="request_date" class="form-label">Request Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="request_date" name="request_date" value="{{ date('Y-m-d') }}" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Materials <span class="text-danger">*</span></label>
                        <div id="materials-container">
                            <div class="row mb-2 material-item">
                                <div class="col-md-7">
                                    <input type="text" class="form-control" name="items[0][product]" placeholder="Material Name" oninput="this.value = this.value.toUpperCase();" required>
                                </div>
                                <div class="col-md-4">
                                    <input type="number" class="form-control" name="items[0][quantity]" placeholder="Quantity" min="1" value="1" required>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger remove-material-btn" disabled>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-info mt-2" id="add-material-btn">
                            <i class="fas fa-plus"></i> Add Another Material
                        </button>
                    </div>
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" oninput="this.value = this.value.toUpperCase();" ></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewDetailsModal" tabindex="-1" aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="viewDetailsModalLabel">Request Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="requestDetailsContent">
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading request details...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Filter -->
<div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="{{ route('user.material_request') }}" method="GET">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="filterModalLabel">Filter Material Request by Date</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            
          <div class="mb-3">
            <label for="start_date" class="form-label">Start Date</label>
            <input type="date" class="form-control" name="start_date" id="start_date" value="{{ request('start_date') }}">
          </div>
          <div class="mb-3">
            <label for="end_date" class="form-label">End Date</label>
            <input type="date" class="form-control" name="end_date" id="end_date" value="{{ request('end_date') }}">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Filter</button>
        </div>
      </div>
    </form>
  </div>
</div>

<style>
.hover-shadow:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    transition: all 0.3s ease;
    cursor: pointer;
}

.request-card {
    transition: all 0.3s ease;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Material row functionality
    let materialIndex = 0;
    
    document.getElementById('add-material-btn').addEventListener('click', function() {
        materialIndex++;
        const newRow = document.createElement('div');
        newRow.className = 'row mb-2 material-item';
        newRow.innerHTML = `
            <div class="col-md-7">
                <input type="text" class="form-control" name="items[${materialIndex}][product]" placeholder="Material Name" oninput="this.value = this.value.toUpperCase();"  required>
            </div>
            <div class="col-md-4">
                <input type="number" class="form-control" name="items[${materialIndex}][quantity]" placeholder="Quantity" min="1" value="1" required>
            </div>
            <div class="col-md-1">
                <button type="button" class="btn btn-danger remove-material-btn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        document.getElementById('materials-container').appendChild(newRow);
        
        // Add event listener to the new remove button
        newRow.querySelector('.remove-material-btn').addEventListener('click', function() {
            this.closest('.material-item').remove();
        });
    });
    
    // Search functionality
    document.getElementById('searchInput').addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        const requestCards = document.querySelectorAll('.request-card-wrapper');
        
        requestCards.forEach(function(card) {
            const cardText = card.textContent.toLowerCase();
            if (cardText.includes(searchTerm)) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    });
    
    // View Details Modal
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    const viewDetailsModal = new bootstrap.Modal(document.getElementById('viewDetailsModal'));
    
    // Function to open modal with request details
    function openDetailsModal(requestId) {
        // Show loading spinner
        document.getElementById('requestDetailsContent').innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading request details...</p>
            </div>
        `;
        
        // Show the modal
        viewDetailsModal.show();
        
        // Fetch request details
        fetch('{{ route('user.material_request.details', '') }}/' + requestId)
            .then(response => response.text())
            .then(data => {
                document.getElementById('requestDetailsContent').innerHTML = data;
            })
            .catch(error => {
                document.getElementById('requestDetailsContent').innerHTML = 
                    '<div class="alert alert-danger">Error loading request details. Please try again.</div>';
            });
    }
    
    // Add click event to both the cards and the details buttons
    viewDetailsButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent card click event from firing
            const requestId = this.getAttribute('data-id');
            openDetailsModal(requestId);
        });
    });
    
    // Make entire card clickable
    document.querySelectorAll('.request-card').forEach(function(card) {
        card.addEventListener('click', function() {
            const requestId = this.getAttribute('data-id');
            openDetailsModal(requestId);
        });
    });
});
</script>
@endsection