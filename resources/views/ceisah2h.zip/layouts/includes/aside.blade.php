<div class="overlay-aside"></div>
<aside tabindex="-1" class="form-aside p-0" id="globalAside">
    <div class="aside-header">
        <span class="aside-title"> </span>
       
    </div>
    <div class="aside-content" id="asideDetailForm">
    </div>
    <div class="aside-footer">
        <div class="container-fluid p-0">
            <div class="row justify-content-center w-100 mx-0 asideFooterBtn">
                <div class="col-6 d-flex justify-content-center justify-content-md-end mb-2 px-0">
                    <div class="skeleton mb-0 w-100 w-md-auto me-2"></div>
                </div>
                <div class="col-6 d-flex justify-content-center justify-content-md-end mb-2 px-0">
                    <div class="skeleton mb-0 w-100 w-md-auto"></div>
                </div>
            </div>
        </div>
    </div>
</aside>